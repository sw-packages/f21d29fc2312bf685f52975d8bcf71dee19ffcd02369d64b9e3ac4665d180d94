/*
 * Copyright (C) 2008 Emweb bv, Herent, Belgium.
 *
 * See the LICENSE file for terms of use.
 */

#include "WebStream.h"

namespace Wt {

WebStream::WebStream()
{ }

WebStream::~WebStream()
{ }

}
